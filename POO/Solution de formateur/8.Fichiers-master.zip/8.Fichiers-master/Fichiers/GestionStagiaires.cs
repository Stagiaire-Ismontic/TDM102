﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fichiers
{
    public class DataStagiaires
    {
        public List<Stagiaire> liste_stagiaires = new List<Stagiaire>();
    }
}
