﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fichiers
{
    public class Stagiaire
    {
        public long Id { get; set; }
        public string Nom { get; set; }
    }
}
